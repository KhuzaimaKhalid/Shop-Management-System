public interface Storable {
    void addItem();
    void updateItem();
    void deleteItem();
}