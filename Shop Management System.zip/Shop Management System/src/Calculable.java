public interface Calculable {
    double calculateTotal();
    double applyTax();
}